# mythicpl.us
A simple flat file site designed to load quickly and give m+ information at a glance.

Huge thank yous to everyone that provided feedback via reddit, github, discord, whatever. 
You are appreciated.
 
## Wall of Fame

**Mitcheljager for initial restyle.<br>
Heliades for assisting with further restyle and for making the sweet EoA map.<br>
Auhsoj for writing most of the script that powers the calc page.<br>
Gnarfoz and chuDr3t4 for doing keystone research.<br>
Shoutouts to my boy Luke for making the auto-rotate script.<br>
Kyatastrophe for shilling my site on the WoW discord.<br>
MattZeeX, for confirming all the time <br>**

**Nery, lord and savior of week 2<br>
Vauira, lord and savior of week 3<br>
Beardofedu, week 4 and 5 master<br>
Variance, week 6 master<br>**

Auchindoun  <br>
JanoschVG <br>
Bettybae <br>
xepheris <br>
stefan0uh <br>
zzzoma <br>
JosKrause <br>
narabug <br>
Felix1216 <br>
Gooberish <br>
Wotuu <br>
omega <br>
Kanegasi <br>
iamaquestionmark <br>
Twodeegee <br>
Spasky <br>
Dreadnip <br>
Ben <br>
lopo <br>
Elemfao <br>
sexybertha, week 3 confirmation!<br>
Asteryx, week 4 confirmation!<br>
Driaidn, week 6 confirmation <br>
Adiuva, week 6 confirmation<br>


